﻿namespace $safeprojectname$.Features.LogIn
{
    public partial class LogInPage
    {
        public LogInPage()
        {
            InitializeComponent();
        }
    }
}