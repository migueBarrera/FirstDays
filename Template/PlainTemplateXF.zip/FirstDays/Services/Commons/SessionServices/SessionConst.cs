﻿namespace $safeprojectname$.Services.Commons
{
    public static class SessionConst
    {
        public static string USERNAME = "USER_NAME";
    }
}
